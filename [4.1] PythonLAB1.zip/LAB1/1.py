# Task 1
def calculate_statistics_from_file(file_name):
    positive_count = 0
    negative_count = 0
    negative_sum = 0

    with open(file_name, 'r') as file:
        for line in file:
            # Split the line into numbers by spaces
            numbers = line.split()
            for number in numbers:
                number = int(number)
                if number > 0:
                    positive_count += 1
                elif number < 0:
                    negative_count += 1
                    negative_sum += number

    # Calculate the average of negative numbers
    negative_average = negative_sum / negative_count if negative_count > 0 else 0

    return positive_count, negative_count, negative_average

file_name = "numbers.txt"
positive_count, negative_count, negative_average = calculate_statistics_from_file(file_name)
print("[!] TASK 1")
print(f"\tNumber of positive numbers: {positive_count}")
print(f"\tNumber of negative numbers: {negative_count}")
print(f"\tAverage of negative numbers: {negative_average}")


