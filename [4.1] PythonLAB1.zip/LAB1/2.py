# Task 2
def determine_triangle_type(a, b, c):
    if a <= 0 or b <= 0 or c <= 0:
        return "Impossible to create segments"

    # Перевіряємо умову існування трикутника (сума довжин будь-яких двох сторін має бути більше третьої сторони)
    if a + b <= c or a + c <= b or b + c <= a:
        return "Impossible to create triangle"

    # Визначаємо тип трикутника
    if a == b == c:
        return "Equilateral triangle" # рівносторонній
    elif a == b or a == c or b == c:
        return "Isosceles triangle" # рівнобедрений
    else:
        return "Versatile triangle" # різносторонній

print("\n[!] TASK 2")
a = float(input("\tInput length of 1st segment: "))
b = float(input("\tInput length of 2nd segment: "))
c = float(input("\tInput length of 3rd segment: "))

result = determine_triangle_type(a, b, c)
print(f"\t\tType of triangle: {result}")