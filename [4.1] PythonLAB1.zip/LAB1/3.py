# Task 3
def print_words_in_column(sentence):
    words = sentence.split()
    for word in words:
        print(f"\t{word}")
print("\n[!] TASK 3")
s = "The world ain`t all sunshine and rainbows"
print_words_in_column(s)