# Task 4
def find_max_sum_rectangle(matrix):
    if not matrix:
        return 0

    rows = len(matrix)
    cols = len(matrix[0])

    max_sum = float('-inf')
    max_left, max_right, max_top, max_bottom = None, None, None, None

    for left in range(cols):
        temp = [0] * rows
        for right in range(left, cols):
            for i in range(rows):
                temp[i] += matrix[i][right]

            current_sum = 0
            current_top = 0
            for bottom in range(rows):
                if current_sum <= 0:
                    current_sum = temp[bottom]
                    current_top = bottom
                else:
                    current_sum += temp[bottom]

                if current_sum > max_sum:
                    max_sum = current_sum
                    max_left = left
                    max_right = right
                    max_top = current_top
                    max_bottom = bottom

    return max_sum, max_left, max_right, max_top, max_bottom

matrix = [
    [1, 2, -1, -4, -20],
    [-8, -3, 4, 2, 1],
    [3, 8, 10, 1, 3],
    [-4, -1, 1, 7, -6]
]

max_sum, left, right, top, bottom = find_max_sum_rectangle(matrix)
print("\n[!] TASK 4")
print(f"\tSubrectangle with the greatest sum: ")
for i in range(top, bottom + 1):
    for j in range(left, right + 1):
        print(f"\t{matrix[i][j]}", end="\t")
    print()
print(f"\n\tSum of this subrectangle: {max_sum}")