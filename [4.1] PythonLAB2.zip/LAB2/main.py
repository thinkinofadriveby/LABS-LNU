import requests
import json

def get_weather_data(city: str) -> dict:
    """
    Отримує дані погоди для заданого міста

    Args:
        city: місто, для якого отримуються дані погоди

    Returns:
        dict з даними погоди для заданого міста
    """

    # Формуємо URL для запиту до API погоди з використанням заданого міста
    api_key = "a24850c38974bbe0509a7c3915c0f07a"  # API ключ
    url = f"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}"  # url

    # Отримуємо дані погоди з інтернету
    response = requests.get(url)
    weather_data = response.json()

    # Перевіряємо, чи отримали ми коректні дані від API
    if response.status_code == 200:
        weather_dict = {
            "city": weather_data.get("name", "Немає інформації про місто"),
            "temperature": weather_data["main"].get("temp", "Немає інформації про температуру"),
            "humidity": weather_data["main"].get("humidity", "Немає інформації про вологість"),
            "pressure": weather_data["main"].get("pressure", "Немає інформації про тиск"),
            "wind_speed": weather_data["wind"].get("speed", "Немає інформації про швидкість вітру"),
            "wind_direction": weather_data["wind"].get("deg", "Немає інформації про напрямок вітру"),
        }
    else:
        # Якщо API повернуло некоректну відповідь, повідомляємо про це
        weather_dict = {"error": "Дані погоди недоступні"}

    return weather_dict

# функція для визначення міста з найнижчою температурою повітря
# city_data_list - це поки пустий список для зберігання даних по містах
def city_with_lowest_temperature(city_data_list):
    lowest_temp = float('inf')
    coldest_city = None

    for city_data in city_data_list:
        temperature = city_data['temperature']
        if temperature < lowest_temp:
            lowest_temp = temperature
            coldest_city = city_data['city']

    return coldest_city, lowest_temp

# функція для знаходження міста з найвищою вологістю повітря
def city_with_highest_humidity(city_data_list):
    highest_humidity = -1
    most_humid_city = None

    for city_data in city_data_list:
        humidity = city_data['humidity']
        if humidity > highest_humidity:
            highest_humidity = humidity
            most_humid_city = city_data['city']

    return most_humid_city, highest_humidity


# фукнція для знаходження середньої швидкості вітру у містах
def average_wind_speed(city_data_list):
    total_wind_speed = 0
    num_cities = len(city_data_list)

    for city_data in city_data_list:
        total_wind_speed += city_data['wind_speed']

    if num_cities > 0:
        average_speed = total_wind_speed / num_cities
    else:
        average_speed = 0

    return average_speed

# функція для знаходження міста з найвищим атмосферним тиском
def city_with_highest_pressure(city_data_list):
    highest_pressure = 0
    highest_pressure_city = None

    for city_data in city_data_list:
        pressure = city_data['pressure']
        if pressure > highest_pressure:
            highest_pressure = pressure
            highest_pressure_city = city_data['city']

    return highest_pressure_city, highest_pressure

# функція для знаходження міста з найнижчою швидкістю вітру
def city_with_lowest_wind_speed(city_data_list):
    lowest_wind_speed = float('inf')
    lowest_wind_speed_city = None

    for city_data in city_data_list:
        wind_speed = city_data['wind_speed']
        if wind_speed < lowest_wind_speed:
            lowest_wind_speed = wind_speed
            lowest_wind_speed_city = city_data['city']

    return lowest_wind_speed_city, lowest_wind_speed


# функція для знаходження середнього значення вологості повітря в містах
def average_humidity(city_data_list):
    total_humidity = 0
    num_cities = len(city_data_list)

    for city_data in city_data_list:
        humidity = city_data['humidity']
        total_humidity += humidity

    if num_cities > 0:
        avg_humidity = total_humidity / num_cities
    else:
        avg_humidity = 0

    return avg_humidity
# функція для обчислення середньої температури повітря в усіх містах
def average_temperature(city_data_list):
    total_temperature = 0
    num_cities = len(city_data_list)

    for city_data in city_data_list:
        temperature = city_data['temperature']
        total_temperature += temperature

    if num_cities > 0:
        avg_temperature = total_temperature / num_cities
    else:
        avg_temperature = 0

    return avg_temperature

def write_weather_info_to_file(city_data_list, filename):
    with open(filename, 'w') as file:
        coldest_city, lowest_temp = city_with_lowest_temperature(city_data_list)

        # тут я віднімаю від температури 273.15 через те, що API повертає температуру в Кельвінах
        # нижче в коді роблю те ж, де потрібно
        file.write(f"Місто з найнижчою температурою повітря: {coldest_city}, {round(lowest_temp - 273.15, 0)} градусів Цельсія\n")

        humid_city, highest_humidity = city_with_highest_humidity(city_data_list)
        file.write(f"Місто з найвищою вологістю повітря: {humid_city}, {highest_humidity}%\n")

        avg_speed = average_wind_speed(city_data_list)
        file.write(f"Середня швидкість вітру в усіх містах: {round(avg_speed, 1)} м/с\n")

        highest_pressure_city, highest_pressure = city_with_highest_pressure(city_data_list)
        file.write(f"Місто з найвищим атмосферним тиском: {highest_pressure_city}, {highest_pressure} гПа\n")

        lowest_wind_speed_city, lowest_wind_speed = city_with_lowest_wind_speed(city_data_list)
        file.write(f"Місто з найнижчою швидкістю вітру: {lowest_wind_speed_city}, {lowest_wind_speed} м/с\n")

        avg_humidity_value = average_humidity(city_data_list)
        file.write(f"Середнє значення вологості в усіх містах: {round(avg_humidity_value, 2)}%\n")

        avg_temp = average_temperature(city_data_list)
        file.write(f"Середня температура в усіх містах: {round(avg_temp - 273.15, 0)} градусів Цельсія\n")



def main():
    choice = input("Оберіть джерело даних (1 - OpenWeatherMap API, 2 - файл): ")
    city_data_list = []  # пустий список для зберігання даних по містах

    if choice == '1':
        while True:
            city_name = input("Введіть назву міста (0 для завершення): ")

            if city_name == '0':
                print('\tФайл з результатами роботи успішно створено!')
                break

            weather_data = get_weather_data(city_name)

            if "error" in weather_data:
                print(f"\tПомилка для міста {city_name}: {weather_data['error']}")
            else:
                # Виводимо дані погоди
                print(f"\tМісто: {weather_data['city']}")
                print(f"\tТемпература: {round(weather_data['temperature'] - 273.15, 1)} градусів Цельсія")
                print(f"\tВологість: {weather_data['humidity']}%")
                print(f"\tТиск: {weather_data['pressure']} гПа")
                print(f"\tШвидкість вітру: {weather_data['wind_speed']} м/с")
                print(f"\tНапрямок вітру: {weather_data['wind_direction']} градусів")

                # Додаємо дані погоди до списку city_data_list
                city_data_list.append(weather_data)

    elif choice == '2':
        filename = input("Введіть назву файлу з даними: ")
        try:
            with open(filename, 'r') as file:
                data = json.load(file)
                city_data_list.extend(data)
                print('Файл з результатами роботи функцій успішно створено!')
        except FileNotFoundError:
            print(f"Файл '{filename}' не знайдено.")
    else:
        print("Неправильний вибір. Виберіть 1 або 2.")
        return

    write_weather_info_to_file(city_data_list, "weather_info.txt")

if __name__ == "__main__":
    main()
