def has_valid_braces(str_eq, verbose=False):
    if not str_eq:
        return True
    st = []
    eq_strip = ''
    brace_inds = ''
    prev = False
    for i, chr in enumerate(str_eq):
        if chr == '(' or chr == ')':
            if prev:
                eq_strip += ' '
                brace_inds += ' '
            eq_strip += chr
            brace_inds += str(i)
            st.append(chr)
            prev = True
        else:
            eq_strip += '.'
            brace_inds += '.'
            prev = False
    if verbose:
        print(eq_strip)
        print(brace_inds)
    if not st:
        return True

    last_chr = st.pop()
    if last_chr == '(':
        return False
    temp_st = [last_chr]
    while st:
        curr_chr = st.pop()
        if curr_chr == ')':
            temp_st.append(curr_chr)
        else:
            if not temp_st:
                return False
            temp_st.pop()

    return len(temp_st) == 0


def task1():
    inp = input('Input expression - ')
    if has_valid_braces(inp, True):
        print('✅ Expression is valid')
    else:
        print('❌ Invalid expression')


def test_has_valid_braces():
    test_inps = '((a + b) + ((a+ b)) + a*(b*b)))', '(a+b*((a+c) - a-k))', ''
    desired_ret = False, True, True

    for inp, true_outp in zip(test_inps, desired_ret):
        ret = has_valid_braces(inp)
        assert ret == true_outp, '❌ Tests for task 1 does not pass.'

    print('✅ All tests for task 1 passed.')


def normalize_braces(str_eq):
    fw_br, bw_br = {'[', '{'}, {']', '}'}
    r = ''
    for chr in str_eq:
        if chr in fw_br:
            r += '('
        elif chr in bw_br:
            r += ')'
        else:
            r += chr
    return r


def is_valid_math_expression(str_eq):
    if not str_eq:
        return True
    x = y = z = 1
    allowed_vars = {'x': x, 'y': y, 'z': z}
    try:
        code = compile(normalize_braces(str_eq), '<string>', 'eval')
        for name in code.co_names:
            if name not in allowed_vars:
                return False
        _ = eval(code, {'__builtins__': {}}, allowed_vars)
        return True
    except SyntaxError:
        return False


def task2():
    inp = input('Input expression - ')
    if is_valid_math_expression(inp):
        print('✅ Expression is valid')
    else:
        print('❌ Invalid expression')


def test_is_valid_math_expression():
    test_inps = 'x + ( y - z - [ x + x ] + { [ z - z - y ] + ( y ) } ) - z', r'{{{x + y + z }}', '', 'asdbc'
    desired_ret = True, False, True, False

    for inp, true_outp in zip(test_inps, desired_ret):
        ret = is_valid_math_expression(inp)
        assert ret == true_outp, '❌ Tests for task 2 does not pass.'

    print('✅ All tests for task 2 passed.')


def evaluate_math_expression(str_eq:str):
    nums, ops = [], []
    for chr in str_eq:
        if chr.isnumeric():
            nums.append(float(chr))
        elif chr == 'S' or chr == 'D':
            ops.append(chr)
        elif chr == ')':
            # if not (nums and ops):
                # return None
            num2, num1 = nums.pop(), nums.pop()
            op_res = (num1 / num2) if ops.pop() == 'D' else (num1 + num2)
            nums.append(op_res)
    return nums.pop() if nums else None


def task3():
    inp = input('Input expression - ')
    res = evaluate_math_expression(inp)
    if res is not None:
        print(f'Result: {res}')
    else:
        print('❌ Invalid expression')


def test_evaluate_math_expression():
    test_inps = 'D(8,S(2,1))', 'D(S(2,1),S(2,1))', '', 'asdasdf'
    desired_ret = 2.667, 1.0, None, None

    for inp, true_outp in zip(test_inps, desired_ret):
        ret = evaluate_math_expression(inp)
        assert (round(ret, 3) if ret is not None else None) == true_outp, '❌ Tests for task 3 does not pass.'

    print('✅ All tests for task 3 passed.')


if __name__ == '__main__':
    # розкоментуйте щоб запустити таски
    test_has_valid_braces()
    # task1()

    test_is_valid_math_expression()
    # task2()

    test_evaluate_math_expression()
    # task3()
