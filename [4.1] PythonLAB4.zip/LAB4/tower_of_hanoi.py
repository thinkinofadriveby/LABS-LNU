class TowerOfHanoi:
    def __init__(self, num_disks):
        self.num_disks = num_disks
        self.towers = {
            'A': [],
            'B': [],
            'C': [],
        }

        # Ініціалізуємо початковий стан, розміщаючи всі диски на стрижні A
        for i in range(num_disks, 0, -1):
            self.towers['A'].append(i)

    def move_disk(self, source, target):
        if not self.towers[source]:
            return False  # Немає диска на основному стрижні
        if not self.towers[target] or self.towers[target][-1] > self.towers[source][-1]:
            disk = self.towers[source].pop()
            self.towers[target].append(disk)
            return True
        return False

    def solve(self):
        def hanoi(n, source, auxiliary, target):
            if n > 0:
                hanoi(n - 1, source, target, auxiliary)
                self.move_disk(source, target)
                self.display_towers()
                hanoi(n - 1, auxiliary, source, target)

        hanoi(self.num_disks, 'A', 'B', 'C')

    def display_towers(self):
        for tower, disks in self.towers.items():
            print(f'Tower {tower}: {disks}')


def task4():
    num_disks = int(input('Input the number of disks: '))
    hanoi = TowerOfHanoi(num_disks)
    print('Initial state:')
    hanoi.display_towers()
    print('Solving Tower of Hanoi...\n')
    hanoi.solve()
    print('\nFinal state:\n')
    hanoi.display_towers()


if __name__ == '__main__':
    # Запустіть цю функцію, щоб виконати завдання 4 і розв'язати задачу
    task4()
