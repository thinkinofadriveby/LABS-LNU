import json
from pprint import pprint
import matplotlib.pyplot as plt

class Queue:
    def __init__(self):
        # Constructor for the Queue class with no parameters

        # Initialize an empty list to store elements in the queue
        self._elements = []

    def empty(self):
        # Check if the queue is empty

        # Returns:
        # - True if the queue is empty
        # - False if the queue is not empty
        return bool(self._elements)

    def size(self):
        # Get the size of the queue

        # Returns:
        # - The number of elements in the queue (an integer)
        return len(self._elements)

    def push(self, item):
        # Add an item to the end of the queue

        # Parameters:
        # - item: The item to be added to the queue
        self._elements.append(item)

    def pop(self, k=0):
        # Remove and return an item from the queue based on its index (default is 0)

        # Parameters:
        # - k: The index of the item to be removed (default is 0)

        if 0 <= k < len(self._elements):
            return self._elements.pop(k)

        # Returns:
        # - The item removed from the queue (if index is valid)
        # - None if the index is out of bounds
        return None

    def find_match(self, predicate, indices=False):
        # Find elements in the queue that match a given predicate

        # Parameters:
        # - predicate: A function that determines whether an element matches a condition
        # - indices: A boolean indicating whether to return indices (True) or elements (False) of matching items
        if indices:
            return [i for i in range(len(self._elements)) if predicate(self._elements[i])]

        # Returns:
        # - A list of matching elements or their indices based on the 'indices' parameter
        return [el for el in self._elements if predicate(el)]

# loading data from file
def load_data_from_json(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
    return data

def sum_items_price(item_list):
    # Calculate the total price of items in a list

    # Parameters:
    # - item_list: A list of items, each with a name and a price
    summ = 0
    for x in item_list:
        summ += x[1]

    # Returns:
    # - The total price of all items in the list
    return summ

def find_vehicles_carrying_item(car_list, item_name):
  """Find vehicles carrying a specific item.

  Args:
    car_list: A list of vehicles, each with a name, license plate, owner,
      fill date, start location, destination, list of items, permission status,
      and intent.
    item_name: The name of the item to search for.

  Returns:
    A list of vehicles carrying the specified item.
  """

  vehicles_with_item = []
  for vehicle in car_list:
    for item in vehicle["items"]:
      if item[0] == item_name:
        vehicles_with_item.append(vehicle)
        break

  return vehicles_with_item


def plot_destination_vs_total_price(car_list):
    # Plot the destination vs total price of goods in a bar chart.

     # Args:
      #  car_list: A list of vehicles, each with a name, license plate, owner,
       #   fill date, start location, destination, list of items, permission status,
       #   and intent.

      # Returns:
       # A matplotlib plot of the destination vs total price of goods in a bar chart.


      total_prices = []
      for vehicle in car_list:
        total_price = sum_items_price(vehicle["items"])
        total_prices.append((vehicle["destination"][1], total_price))

      # Sort the data by destination.
      total_prices.sort(key=lambda x: x[0])

      # Create a bar chart.
      plt.bar([x[0] for x in total_prices], [x[1] for x in total_prices], color="purple")

      # Add a title and labels to the axes.
      plt.title("Total price of goods in destination")
      plt.xlabel("Destination")
      plt.ylabel("Total price, billions ")

      # Show the plot.
      plt.show()


# creating queues for green and red vehicles
def create_queues(car_list):
    g_q, r_q = Queue(),  Queue()
    for x in car_list:
        ap_q = r_q if x['intend'] == 'red' else g_q
        ap_q.push(x)
    return g_q, r_q


# validate vehicles' permissions and remove those that don't have permission
def validate_queue(q, queue_name=''):
    forbidden_inds = q.find_match(lambda x: not x['has_permission'], indices=True)
    queue_name = queue_name or 'queue'
    for x in forbidden_inds:
        item = q.pop(x)
        print(f"\n❌ Removed {item['vehicle']} {item['license_plate']} from {queue_name} as it doesn't have necessary permissions.")
    print(f'✅ Validated {queue_name}.')


def main():
    # Load data from the JSON file
    data = load_data_from_json("car_data.json")

    car_list = []
    for x in data:
        car_list.append(x)

    # create queues for green and red vehicles
    green_q, red_q = create_queues(car_list)
    print("Data:")
    pprint(car_list, indent=4)

    # validate queues (remove vehicles that don't have permissions)
    validate_queue(green_q, 'Green Queue')
    validate_queue(red_q, 'Red Queue')
    print()

    # Find vehicles that have a specific item
    search_prod = 'Coca-Cola'
    pred = lambda x: any(p[0] == search_prod for p in x['items'])
    print(f'🔎 Looking for item {search_prod}...')
    gq_match_inds = green_q.find_match(pred, indices=True)
    rq_match_inds = red_q.find_match(pred, indices=True)
    print(f"\tVehicles indices that have item {repr(search_prod)} in Green Queue: {', '.join(map(str, gq_match_inds))}")
    print(f"\tVehicles indices that have item {repr(search_prod)} in Red Queue: {', '.join(map(str, rq_match_inds))}")
    print()

    # Find vehicles with a specific destination
    destination = 'Simferopol'
    pred = lambda x: x['destination'][1] == destination
    print(f'🔎 Looking for vehicles with destination {destination}...')
    gq_match_lic = [item['license_plate'] for item in green_q.find_match(pred)]
    print(f"\tVehicles that have destination {destination} in Green Queue: {', '.join(gq_match_lic)}")
    rq_match_lic = [item['license_plate'] for item in red_q.find_match(pred)]
    print(f"\tVehicles that have destination {destination} in Red Queue: {', '.join(rq_match_lic) or 'not found'}")
    print()

    # Find the vehicle with the highest total value of items
    max_value = 0
    max_vehicle = None
    for vehicle in car_list:
        total_value = sum_items_price(vehicle['items'])
        if total_value > max_value:
            max_value = total_value
            max_vehicle = vehicle

    if max_vehicle:
        print(f"🚗 Vehicle with the highest total value of items: {max_vehicle['vehicle']} ({max_vehicle['license_plate']})")
        print(f"\t💰 Total value: 💲{max_value}")
    else:
        print("\t ❌ No vehicle found with items.")

    # Find vehicles carrying a solar panel
    item = "solar panel"
    vehicles_with_item = find_vehicles_carrying_item(car_list, item)

    # Print the results.
    print(f"\n🚗 Vehicles carrying a {item}:")
    for vehicle in vehicles_with_item:
        print(f"\t{vehicle['vehicle']} ({vehicle['license_plate']})")

    # show graph of total price of goods in cities
    plot_destination_vs_total_price(car_list)

if __name__ == '__main__':
    main()
