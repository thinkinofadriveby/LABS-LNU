import time
from pathlib import Path
from datetime import datetime
from itertools import cycle
import tkinter as tk
from random import randint
from tkinter import ttk

def create_dir_with_test_files(dpath, n_files=11, wait_on_create=False, exts=('.txt',)):
    """
        Створює директорію з тестовими файлами.

        :param dpath: Шлях до директорії, яку потрібно створити та заповнити файлами.
        :param n_files: Кількість файлів, які потрібно створити.
        :param wait_on_create: Чи чекати після створення кожного файлу.
        :param exts: Кортеж розширень файлів для створення.
        """
    dpath.mkdir(exist_ok=True)
    exts = cycle(exts)
    for i in range(n_files):
        new_f = dpath / f'file{i}{next(exts)}'
        if new_f.exists():
            continue
        new_f.touch()
        if wait_on_create:
            time.sleep(1)

def task1():
    """
         завдання 1 - пошук найстарших і найновіших файлів у директорії.
        """
    dpath = Path('task1_dir')
    result_text.delete(1.0, tk.END)  # Очищаємо текстовий віджет
    result_text.insert(tk.END, 'Generating test data for task 1...\n')
    create_dir_with_test_files(dpath, n_files=5, wait_on_create=True)

    paths = [(p, p.stat().st_ctime) for p in dpath.iterdir() if p.is_file()]
    paths.sort(key=lambda item: item[1])

    str_fmt, date_fmt = '{0} - {1}', r'%d/%m/%y %H:%M:%S'
    result_text.insert(tk.END, '\nOldest two files:\n')
    result_text.insert(tk.END, '\n'.join((str_fmt.format(p, datetime.fromtimestamp(t).strftime(date_fmt)) for p, t in paths[:2])) + '\n\n')
    result_text.insert(tk.END, 'Newest two files:\n')
    result_text.insert(tk.END, '\n'.join((str_fmt.format(p, datetime.fromtimestamp(t).strftime(date_fmt)) for p, t in paths[-2:])) + '\n\n')

def create_task2_test_files(dpath1, dpath2, n_files=9):
    """
        Створює тестові файли для завдання 2 - порівняння директорій.
        """
    result_text.delete(1.0, tk.END)  # Очищаємо текстовий віджет
    result_text.insert(tk.END, 'Generating test data for task 2...\n')
    create_dir_with_test_files(dpath1, n_files)
    create_dir_with_test_files(dpath2, n_files)

    for p in list(dpath2.iterdir())[:n_files // 2 + 1]:
        with p.open('w') as fid:
            fid.write('123456')

def task2():
    """
       Виконує завдання 2 - знаходить дубльовані файли в двох директоріях.
       """
    dpath1, dpath2 = Path('task2_dir1'), Path('task2_dir2')
    create_task2_test_files(dpath1, dpath2)

    fpsts1 = set((p.name, p.stat().st_size) for p in dpath1.iterdir())
    fpsts2 = set((p.name, p.stat().st_size) for p in dpath2.iterdir())

    dups = sorted(p for p, _ in fpsts1 & fpsts2)
    result_text.insert(tk.END, f"\nDuplicate files in directories {repr(dpath1.name)} and {repr(dpath2.name)} are: {', '.join(dups)}\n\n")

def task3():
    """
       Виконує завдання 3 - пошук файлів з певним розширенням в піддиректоріях.
       """
    rpath = Path('task3')
    rpath.mkdir(exist_ok=True)

    dpaths = [rpath / f'dir{i}' for i in range(4)]
    exts = '.doc', '.py', '.txt', '.dll', '.exe', '.json', '.pdf', '.jpg', '.xml'
    result_text.delete(1.0, tk.END)  # Очищаємо текстовий віджет
    result_text.insert(tk.END, 'Generating test data for task 3...\n')
    for dpath in dpaths:
        create_dir_with_test_files(dpath, n_files=randint(5, 10), exts=exts)

    target_ext = '.exe'
    result_text.insert(tk.END, f"\nFound {repr(target_ext)} files in subdirectories of {repr(rpath)}: {', '.join(map(str, rpath.glob(f'*/*{target_ext}')))}\n\n")

def task4():
    """
        Виконує завдання 4 - переміщення файлів в директорії згідно з розширенням.
        """
    rpath = Path('task4')
    rpath.mkdir(exist_ok=True)

    exts = '.doc', '.py', '.txt'
    dpaths = [rpath / f'{e[1:]}_dir' for e in exts]
    result_text.delete(1.0, tk.END)  # Очищаємо текстовий віджет
    result_text.insert(tk.END, 'Generating test data for task 4...\n')
    create_dir_with_test_files(rpath, n_files=11, exts=exts)

    ext_ddir_map = dict(zip(exts, dpaths))
    for e in exts:
        target_d = ext_ddir_map[e]
        target_d.mkdir(exist_ok=True)
        for f in rpath.glob(f'*{e}'):
            out_path = target_d / f.name
            out_path.unlink(missing_ok=True)
            f.rename(out_path)
            result_text.insert(tk.END, f'\nMoved file {repr(f.name)} to directory {repr(str(target_d))}\n')

def execute_task(task_func):
    task_func()

app = tk.Tk()
app.title("File Tasks")

frame = ttk.Frame(app)
frame.grid(column=0, row=0, padx=10, pady=10)

task1_button = ttk.Button(frame, text="Task 1", command=lambda: execute_task(task1))
task2_button = ttk.Button(frame, text="Task 2", command=lambda: execute_task(task2))
task3_button = ttk.Button(frame, text="Task 3", command=lambda: execute_task(task3))
task4_button = ttk.Button(frame, text="Task 4", command=lambda: execute_task(task4))

task1_button.grid(column=0, row=0, padx=10, pady=5)
task2_button.grid(column=0, row=1, padx=10, pady=5)
task3_button.grid(column=0, row=2, padx=10, pady=5)
task4_button.grid(column=0, row=3, padx=10, pady=5)

result_text = tk.Text(app, wrap=tk.WORD, width=40, height=10)
result_text.grid(column=1, row=0, padx=10, pady=10)

app.mainloop()
