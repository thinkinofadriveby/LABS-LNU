import os
import glob
import subprocess


APP_DIR = os.path.abspath('.')

def get_path_object_name(fp):
    return os.path.split(fp)[1]


def task1():
    print(os.listdir('.'))
    img_fp = os.path.join(APP_DIR, 'image.jpg') # target image path
    doc_fp = os.path.join(APP_DIR, 'document.docx') # target document path

    img_name, doc_name = get_path_object_name(img_fp), get_path_object_name(doc_fp)
    print(f'Opening {img_name}...')
    os.startfile(img_fp)  # opening image
    print(f'Opened {img_name}')

    print(f'Opening {doc_name}...')
    os.startfile(doc_fp)  # opening document
    print(f'Opened {doc_name}')


def task2():
    vscode_fp = r'C:\Users\nazar\OneDrive\Робочий стіл\4.1\Python\LAB7\Code.exe' # path to text editor file
    fps = [os.path.join(APP_DIR, x) for x in glob.glob(os.path.join(APP_DIR, '*.txt'))] # txt file paths
    print(f'Using VS Code as a text editor')
    print('\n'.join((f'Opening {fp}...' for fp in fps)))
    os.execl(vscode_fp, ' ', *fps)  # executing program


def task3():
    script = os.path.join(os.path.abspath('.'), 'test_subproc_sum_app.py') # path to summation program
    # get two numbers for calculation
    a = int(input('Input a number: '))
    b = int(input('Input a number: '))
    subprocess.run(f'python {script} {a} {b}')  # format and execute target command
    with open('result.txt', 'r') as fid:
        print(f'Sum of two numbers: {fid.read()}')


if __name__ == '__main__':
    # uncomment to run a task
    task1()
    # task2()
    task3()
