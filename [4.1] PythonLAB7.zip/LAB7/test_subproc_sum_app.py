import sys

a, b = map(int, sys.argv[1:])

with open('result.txt', 'w') as fid:
    fid.write(str(a+b))
