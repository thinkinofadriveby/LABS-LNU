import os  # Імпорт модуля для взаємодії з операційною системою
import http.client  # Імпорт модуля для роботи з HTTP-з'єднаннями
import urllib.request  # Імпорт модуля для роботи з URL-запитами
import xml.etree.ElementTree as ET  # Імпорт модуля для роботи з XML-деревом

# Декоратор для обробки помилок в функціях
def log_error(task_name, throw_exc=False):
    def decorator(fn):
        def inner(*args, **kwargs):
            try:
                return fn(*args, **kwargs)
            except Exception as exc:
                # Вивід повідомлення про помилку
                print(f'An error occured when running task {repr(task_name)}: {exc}')
                if throw_exc:
                    raise exc
        return inner
    return decorator

# Декорована функція task2()
@log_error(task_name='task 2')
def task2():
    # Змінні для встановлення адреси сервера та кінцевої точки URL
    host, endpoint = 'www.php.net', '/manual/en/intro-whatis.php'
    # Шлях до локального файлу
    local_page_path = os.path.join(os.path.abspath('.'), 'page1.html')
    server = http.client.HTTPSConnection(host)  # Створення HTTPS-з'єднання
    server.request('GET', endpoint)  # Відправлення GET-запиту
    res = server.getresponse()  # Отримання відповіді
    if res.status != 200:
         # Викидання виключення у разі отримання статусу відмови
         raise RuntimeError(f'Error sending request {res.status, res.reason}')
    with open(local_page_path, 'wb') as fid:
        fid.write(res.read())  # Запис відповіді у файл
    res.close()
    os.startfile(local_page_path)  # Відкриття локального файлу

# Декорована функція task3()
@log_error(task_name='task 2')
def task3():
    url = 'https://www.php.net/manual/en/tutorial.php'  # URL-адреса
    local_page_path = 'page2.html'  # Шлях до локального файлу
    temp_page_path, _ = urllib.request.urlretrieve(url)  # Завантаження сторінки
    if not os.path.exists(local_page_path):
        os.rename(temp_page_path, local_page_path)  # Перейменування файлу
    os.startfile(local_page_path)  # Відкриття локального файлу

# Декорована функція task4()
@log_error(task_name='task 4')
def task4():
    target_page_path = os.path.join(os.path.abspath('.'), 'data.xml')  # Шлях до XML-файлу
    tree = ET.parse(target_page_path)  # Читання XML-файлу
    print('Information about countries:', end='\n\n')  # Виведення заголовка
    pt_template = 'Name: {0}\nRank: {1}\nYear: {2}\nGDP PC: {3}\nNeighbors: {4}'  # Шаблон для виведення
    for cntry in tree.getroot().findall('country'):  # Перегляд країн
        name = cntry.attrib['name']  # Отримання назви країни
        rank = cntry.find('rank').text  # Отримання значення рангу
        year = cntry.find('year').text  # Отримання року
        gdppc = cntry.find('gdppc').text  # Отримання значення ВВП на душу населення
        neighbors = (n.attrib['name'] for n in cntry.findall('neighbor'))  # Отримання сусідів країни
        # Виведення інформації про країну
        print(pt_template.format(name, rank, year, gdppc, ', '.join(neighbors)), end='\n\n')

# Основна функція
def main():
    # Розкоментуйте будь-яке завдання для його виконання
    task2()
    # task3()
    # task4()

if __name__ == '__main__':
    main()
