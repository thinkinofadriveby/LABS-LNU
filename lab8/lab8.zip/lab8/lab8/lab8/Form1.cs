﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;

namespace lab8
{
    public partial class Form1 : Form
    {
        private readonly Dictionary<string, List<string>> _openedFiles;
        private WordProcessor _wordProcessor;
        private readonly ConcurrentDictionary<int, int> _threadInfo;
        private Stopwatch _stopwatch;


        public Form1()
        {
            this._openedFiles = new Dictionary<string, List<string>>();
            this._threadInfo = new ConcurrentDictionary<int, int>();
            this._stopwatch = new Stopwatch();

            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm()
        {
            this.label1.Visible = false;
            this.label3.Visible = false;
            this.dataGridView1.Visible = false;
            this.button1.Visible = false;

            InitalizeDataGrid();
        }
        
        private void InitalizeDataGrid()
        {
            dataGridView1.ColumnCount = 2;
            dataGridView1.Columns[0].Name = "ThreadID";
            dataGridView1.Columns[1].Name = "Number of Occurences";
            this.dataGridView1.MultiSelect = false;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._openedFiles.Clear();
            this._threadInfo.Clear();
            FolderBrowserDialog openFolderDialog = new FolderBrowserDialog();

            DialogResult dialogResult = openFolderDialog.ShowDialog();

            if (dialogResult == DialogResult.Cancel)
            {
                return;
            }

            if (dialogResult == DialogResult.Abort)
            {
                return;
            }

            IEnumerable<string> fileNames = Directory.EnumerateFiles(openFolderDialog.SelectedPath);

            foreach (var currentFileName in fileNames)
            {
                try
                {
                    this._openedFiles.Add(currentFileName, File.ReadAllLines(currentFileName).ToList());
                }
                catch (Exception exception)
                {
                    this._openedFiles.Clear();
                    MessageBox.Show(
                        exception.Message +
                        $@"Cannot open {currentFileName}!",
                        @"Error",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                    return;
                }
            }
            FinishFileOpening(fileNames.ToArray());
        }
        
        private void FinishFileOpening(string[] fileNames)
        {
            this._wordProcessor = new WordProcessor(this._openedFiles);
            this.SetFileNamesHeader(fileNames);
            
            this.dataGridView1.Visible = true;
            this.button1.Visible = true;
            this.label2.Visible = false;
            this.label3.Visible = true;
        }
        
        private void SetFileNamesHeader(string[] fileNames)
        {
            this.label1.Text = $@"Number of opened files: {fileNames.Length}";
            this.label1.Visible = true;
        }
        
        
        private async void button1_Click(object sender, EventArgs e)
        {
            InitializeApplicationStart();
            await Task.Run(this.FormOutputFile);
            this._stopwatch.Stop();
            this.UpdateDataGrid();
            InitializeApplicationEnd();
        }

        private void InitializeApplicationStart()
        {
            this._stopwatch.Reset();
            this._stopwatch.Start();

            this.button1.Enabled = false;
            this.openToolStripMenuItem.Enabled = false;
        }
        
        private void InitializeApplicationEnd()
        {
            this.button1.Enabled = true;
            this.openToolStripMenuItem.Enabled = true;
        }

        private void FormOutputFile()
        {
            this._wordProcessor.ShareThreadInfo += UpdateThreadsInfo;
            this._wordProcessor.StartOperationForTheThread();
        }

        private void UpdateThreadsInfo(int threadId)
        {
            this._threadInfo.AddOrUpdate(threadId, 1, (k, v) => v + 1);
        }

        private void UpdateDataGrid()
        {
            foreach (var current in this._threadInfo)
            {
                this.dataGridView1.Rows.Add(current.Key, current.Value);
            }
        }

        private void timer1_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.label3.Text = $@"{this._stopwatch.Elapsed:hh\:mm\:ss\:ffff}";
        }
    }
}