﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace lab8
{
    public class WordProcessor
    {
        private Dictionary<string, List<string>> _openedFiles;
        public Action<int> ShareThreadInfo { get; set; }

        public WordProcessor(Dictionary<string, List<string>> openedFiles)
        {
            this._openedFiles = new Dictionary<string, List<string>>(openedFiles);
        }

        public void StartOperationForTheThread()
        {
            List<Thread> threads = new List<Thread>();

            for (int i = 0; i < this._openedFiles.Count; i++)
            {
                int index = i;
                threads.Add(new Thread(() =>
                {
                    lock (this._openedFiles)
                    {
                        int currentThreadId = Thread.CurrentThread.ManagedThreadId;
                    
                        string keyFileName = this._openedFiles.Keys.ToList()[index];
                        List<string> currentLinesList = this._openedFiles[keyFileName];
                        List<string> tempLinesList = new List<string>();

                        int iterationRightBound = currentLinesList.Count - 6 - index;

                        for (int j = currentLinesList.Count - 1; j >= iterationRightBound; j--)
                        {
                            tempLinesList.Add(currentLinesList[j]);
                            currentLinesList.RemoveAt(j);
                        }

                        currentLinesList = tempLinesList.Concat(currentLinesList).ToList();

                        string newFileName = keyFileName.Substring(0, keyFileName.Length - 4) + "_copy_" + currentThreadId + ".txt";
                        using (var stream = File.CreateText(newFileName))
                        {
                            foreach (var currLine in currentLinesList)
                            {
                                stream.WriteLine(currLine);
                            }
                        }
                    
                        this.ShareThreadInfo(currentThreadId);
                    }
                }));
                threads[i].Start();
            }

            int threadsArraySize = threads.Count;
            for (int i = threadsArraySize / 2; i < threadsArraySize; i++)
            {
                threads[i].Join();
            }

            for (int i = 0; i < threadsArraySize / 2; i++)
            {
                threads[i].Join();
            }
        }
    }
}
